# GENERATED VERSION FILE
# TIME: Fri May 16 22:41:22 2025
__version__ = '0.3.0'
__gitsha__ = 'a4abfb2'
version_info = (0, 3, 0)
